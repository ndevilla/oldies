void Crumble_buy(char * what, int quantity, char * unit);

